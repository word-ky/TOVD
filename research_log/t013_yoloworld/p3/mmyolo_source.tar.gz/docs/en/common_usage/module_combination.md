# Module combination
